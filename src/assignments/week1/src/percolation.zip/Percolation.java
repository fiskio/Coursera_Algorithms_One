public class Percolation {
    
    private final boolean[] grid, topConnected, bottomConnected;
    private final int size;
    private final WeightedQuickUnionUF foo;
    private boolean percolates = false;
    
    // create N-by-N grid, with all sites blocked
    public Percolation(int N) {
        
        if (N <= 0) { throw new IllegalArgumentException(); }
        
        grid = new boolean[N*N];
        topConnected = new boolean[N*N];
        bottomConnected = new boolean[N*N];
        // Arrays.fill(grid, Boolean.FALSE); // FALSE = blocked
        for (int i = 0; i < N*N; i++) { 
            grid[i] = false; 
            topConnected[i] = false; 
            topConnected[i] = false; 
        }
        foo = new WeightedQuickUnionUF(N*N);
        size = N;
    } 
    
    // open site (row i, column j) if it is not already
    public void open(int i, int j) {
        
        checkBoundaries(i, j);
        
        if (i == 1 && j == 1 && size == 1) {
            grid[flatten(i, j)] = true;
            percolates = true;
            topConnected[0] = true;
            return;
        }
         
        int root = findRoot(i, j);
        // top?
        if (i == 1) {
            topConnected[root] = true;
        }
        // bottom?
        if (i == size) {
           bottomConnected[root] = true;
        }
        grid[flatten(i, j)] = Boolean.TRUE;
        
        // open top
        if (j != 1 && isOpen(i, j-1)) {
            mergeFlow2(i, j, i, j-1);
            // foo.union(flatten(i, j-1), origin);
        }
        // open bottom
        if (j != size && isOpen(i, j+1)) {
            mergeFlow2(i, j, i, j+1);
            // foo.union(flatten(i, j+1), origin);
        }
        // open left
        if (i != 1 && isOpen(i-1, j)) {
            mergeFlow2(i, j, i-1, j);
            // foo.union(flatten(i-1, j), origin);
        }
        // open right
        if (i != size && isOpen(i+1, j)) {
            mergeFlow2(i, j, i+1, j);
            // foo.union(flatten(i+1, j), origin);
        }
        
        
    }
    
    private int findRoot(int i, int j) {
        return foo.find(flatten(i, j));
    }
    
    private void mergeFlow2(int i, int j, int s, int t) {
       
        boolean isTopConnected = false;
        boolean isBoottomConnected = false;
        
        int rootA = findRoot(i, j);
        int rootB = findRoot(s, t);
        
        if (topConnected[rootA] || topConnected[rootB]) {
            isTopConnected = true;
        }
        if (bottomConnected[rootA] || bottomConnected[rootB]) {
            isBoottomConnected = true;
        }
        
        foo.union(flatten(i, j), flatten(s, t));
        
        int rootNewA = findRoot(i, j);
        //int rootNewB = findRoot(s, t);
        //assert rootNewA == rootNewB;
        
        if (isTopConnected)     { topConnected[rootNewA]    = true; }
        if (isBoottomConnected) { bottomConnected[rootNewA] = true; }
       
        // percolates?
        int rootNew = findRoot(i, j);
        if (topConnected[rootNew] && bottomConnected[rootNew]) {
            percolates = true;
        }
        
    }
    
    // is site (row i, column j) open?
    public boolean isOpen(int i, int j) {
        checkBoundaries(i, j);
        return grid[flatten(i, j)];
    }
    
    // is site (row i, column j) full?
    public boolean isFull(int i, int j) {
        checkBoundaries(i, j);
        return topConnected[foo.find(flatten(i, j))];
    }
    
    // does the system percolate?
    public boolean percolates() {
        return percolates;
    }
    
    /**
     * Converts a two dimensional coordinate (starting index 1)
     * to its one dimensional equivalent (starting index 0)
     * @param x row
     * @param y column
     * @return
     */
    private int flatten(int x, int y) {
        return size * (y-1) + (x-1);
    }
    
    private void checkBoundaries(int i, int j) {
        
        if (i < 1 || j < 1 || j > size || i > size) {
            throw new IndexOutOfBoundsException();
        }
    }
 }